//
//  ViewController.h
//  testForEmptyView
//
//  Created by andylym on 2025/3/7.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

