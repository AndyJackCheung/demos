//
//  ViewController.m
//  testForEmptyView
//
//  Created by andylym on 2025/3/7.
//

#import "ViewController.h"
#import "ACEmptyViewHeader.h"

@interface ViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITableView *tableView;


@property (nonatomic, strong) NSMutableArray *dataMArr;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.dataMArr = [NSMutableArray array];
    ACEmptyView*emptyView=[ACEmptyView emptyViewWithImageStr:@"noData" titleStr:@"Here is no datas."];
    self.tableView.AC_emptyView = emptyView;
    
    
}




- (nonnull UITableViewCell *)tableView:(nonnull UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath { 
    UITableViewCell *cell;
    if (!cell) {
        cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    }
    cell.textLabel.text = self.dataMArr[indexPath.row];
    return cell;
}

- (NSInteger)tableView:(nonnull UITableView *)tableView numberOfRowsInSection:(NSInteger)section { 
    return  self.dataMArr.count;
}





@end
