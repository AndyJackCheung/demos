//
//  UIScrollView+Empty.m
//
//
//  Created by andylym on 2025/3/7.
//

#import "UIScrollView+Empty.h"
#import <objc/runtime.h>
#import "ACEmptyView.h"

@implementation NSObject (MJRefresh)

+ (void)exchangeInstanceMethod1:(SEL)method1 method2:(SEL)method2
{
    method_exchangeImplementations(class_getInstanceMethod(self, method1), class_getInstanceMethod(self, method2));
}

@end

@implementation UIScrollView (Empty)

#pragma mark - Setter/Getter

static char kEmptyViewKey;
- (void)setAC_emptyView:(ACEmptyView *)AC_emptyView{
    if (AC_emptyView != self.AC_emptyView) {

        objc_setAssociatedObject(self, &kEmptyViewKey, AC_emptyView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);

        for (UIView *view in self.subviews) {
            if ([view isKindOfClass:[ACEmptyView class]]) {
                [view removeFromSuperview];
            }
        }
        [self addSubview:self.AC_emptyView];
    }
}
- (ACEmptyView *)AC_emptyView{
    return  objc_getAssociatedObject(self, &kEmptyViewKey);
}

#pragma mark - Private Method
- (NSInteger)totalDataCount
{
    NSInteger totalCount = 0;
    if ([self isKindOfClass:[UITableView class]]) {
        UITableView *tableView = (UITableView *)self;

        for (NSInteger section = 0; section < tableView.numberOfSections; section++) {
            totalCount += [tableView numberOfRowsInSection:section];
        }
    } else if ([self isKindOfClass:[UICollectionView class]]) {
        UICollectionView *collectionView = (UICollectionView *)self;

        for (NSInteger section = 0; section < collectionView.numberOfSections; section++) {
            totalCount += [collectionView numberOfItemsInSection:section];
        }
    }
    return totalCount;
}

- (void)getDataAndSet{

    if ([self totalDataCount] == 0) {
        [self show];
    }else{
        [self hide];
    }
}

- (void)show{

    //当不自动显隐时，内部自动调用show方法时也不要去显示，要显示的话只有手动去调用 AC_showEmptyView
    if (!self.AC_emptyView.autoShowEmptyView) {
        self.AC_emptyView.hidden = YES;
        return;
    }

    [self AC_showEmptyView];
}
- (void)hide{

    if (!self.AC_emptyView.autoShowEmptyView) {
        self.AC_emptyView.hidden = YES;
        return;
    }

    [self AC_hideEmptyView];
}

#pragma mark - Public Method
- (void)AC_showEmptyView{

    [self.AC_emptyView.superview layoutSubviews];

    self.AC_emptyView.hidden = NO;
    //让 emptyBGView 始终保持在最上层
    [self bringSubviewToFront:self.AC_emptyView];
}
- (void)AC_hideEmptyView{
    self.AC_emptyView.hidden = YES;
}

- (void)AC_startLoading{
    self.AC_emptyView.hidden = YES;
}
- (void)AC_endLoading{
    if ([self totalDataCount] == 0) {
        self.AC_emptyView.hidden = NO;
    }else{
        self.AC_emptyView.hidden = YES;
    }
}

@end

@implementation UITableView (Empty)
+ (void)load{

    [self exchangeInstanceMethod1:@selector(reloadData) method2:@selector(AC_reloadData)];

    ///section
    [self exchangeInstanceMethod1:@selector(insertSections:withRowAnimation:) method2:@selector(AC_insertSections:withRowAnimation:)];
    [self exchangeInstanceMethod1:@selector(deleteSections:withRowAnimation:) method2:@selector(AC_deleteSections:withRowAnimation:)];

    ///row
    [self exchangeInstanceMethod1:@selector(insertRowsAtIndexPaths:withRowAnimation:) method2:@selector(AC_insertRowsAtIndexPaths:withRowAnimation:)];
    [self exchangeInstanceMethod1:@selector(deleteRowsAtIndexPaths:withRowAnimation:) method2:@selector(AC_deleteRowsAtIndexPaths:withRowAnimation:)];
}
- (void)AC_reloadData{
    [self AC_reloadData];
    [self getDataAndSet];
}
///section
- (void)AC_insertSections:(NSIndexSet *)sections withRowAnimation:(UITableViewRowAnimation)animation{
    [self AC_insertSections:sections withRowAnimation:animation];
    [self getDataAndSet];
}
- (void)AC_deleteSections:(NSIndexSet *)sections withRowAnimation:(UITableViewRowAnimation)animation{
    [self AC_insertSections:sections withRowAnimation:animation];
    [self getDataAndSet];
}

///row
- (void)AC_insertRowsAtIndexPaths:(NSArray<NSIndexPath *> *)indexPaths withRowAnimation:(UITableViewRowAnimation)animation{
    [self AC_insertRowsAtIndexPaths:indexPaths withRowAnimation:animation];
    [self getDataAndSet];
}
- (void)AC_deleteRowsAtIndexPaths:(NSArray<NSIndexPath *> *)indexPaths withRowAnimation:(UITableViewRowAnimation)animation{
    [self AC_deleteRowsAtIndexPaths:indexPaths withRowAnimation:animation];
    [self getDataAndSet];
}


@end

@implementation UICollectionView (Empty)
+ (void)load{

    [self exchangeInstanceMethod1:@selector(reloadData) method2:@selector(AC_reloadData)];

    ///section
    [self exchangeInstanceMethod1:@selector(insertSections:) method2:@selector(AC_insertSections:)];
    [self exchangeInstanceMethod1:@selector(deleteSections:) method2:@selector(AC_deleteSections:)];

    ///item
    [self exchangeInstanceMethod1:@selector(insertItemsAtIndexPaths:) method2:@selector(AC_insertItemsAtIndexPaths:)];
    [self exchangeInstanceMethod1:@selector(deleteItemsAtIndexPaths:) method2:@selector(AC_deleteItemsAtIndexPaths:)];

}
- (void)AC_reloadData{
    [self AC_reloadData];
    [self getDataAndSet];
}
///section
- (void)AC_insertSections:(NSIndexSet *)sections{
    [self AC_insertSections:sections];
    [self getDataAndSet];
}
- (void)AC_deleteSections:(NSIndexSet *)sections{
    [self AC_deleteSections:sections];
    [self getDataAndSet];
}
///item
- (void)AC_insertItemsAtIndexPaths:(NSArray<NSIndexPath *> *)indexPaths{
    [self AC_insertItemsAtIndexPaths:indexPaths];
    [self getDataAndSet];
}
- (void)AC_deleteItemsAtIndexPaths:(NSArray<NSIndexPath *> *)indexPaths{
    [self AC_deleteItemsAtIndexPaths:indexPaths];
    [self getDataAndSet];
}
@end
