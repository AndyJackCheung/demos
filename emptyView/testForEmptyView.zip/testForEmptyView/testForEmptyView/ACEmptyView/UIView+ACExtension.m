//
//  UIView+ACExtension.m
//
//
//  Created by andylym on 2025/3/7.
//

#import "UIView+ACExtension.h"

@implementation UIView (ACExtension)

- (void)setAC_x:(CGFloat)AC_x{

    CGRect frame = self.frame;
    frame.origin.x = AC_x;
    self.frame = frame;
}
- (CGFloat)AC_x
{
    return self.frame.origin.x;
}

- (void)setAC_y:(CGFloat)AC_y{

    CGRect frame = self.frame;
    frame.origin.y = AC_y;
    self.frame = frame;
}
- (CGFloat)AC_y
{
    return self.frame.origin.y;
}

- (void)setAC_centerX:(CGFloat)AC_centerX{
    CGPoint center = self.center;
    center.x = AC_centerX;
    self.center = center;
}
- (CGFloat)AC_centerX
{
    return self.center.x;
}

- (void)setAC_centerY:(CGFloat)AC_centerY
{
    CGPoint center = self.center;
    center.y = AC_centerY;
    self.center = center;
}
- (CGFloat)AC_centerY
{
    return self.center.y;
}

- (void)setAC_width:(CGFloat)AC_width
{
    CGRect frame = self.frame;
    frame.size.width = AC_width;
    self.frame = frame;
}
- (CGFloat)AC_width
{
    return self.frame.size.width;
}

- (void)setAC_height:(CGFloat)AC_height
{
    CGRect frame = self.frame;
    frame.size.height = AC_height;
    self.frame = frame;
}
- (CGFloat)AC_height
{
    return self.frame.size.height;
}

- (void)setAC_size:(CGSize)AC_size
{
    CGRect frame = self.frame;
    frame.size = AC_size;
    self.frame = frame;
}
- (CGSize)AC_size
{
    return self.frame.size;
}

- (void)setAC_origin:(CGPoint)AC_origin
{
    CGRect frame = self.frame;
    frame.origin = AC_origin;
    self.frame = frame;
}

- (CGPoint)AC_origin
{
    return self.frame.origin;
}
- (CGFloat)AC_maxX{
    return self.frame.origin.x + self.frame.size.width;
}
- (CGFloat)AC_maxY{
    return self.frame.origin.y + self.frame.size.height;
}

@end

