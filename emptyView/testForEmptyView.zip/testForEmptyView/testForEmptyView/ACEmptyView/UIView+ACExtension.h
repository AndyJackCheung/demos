//
//  UIView+ACExtension.h
//
//
//  Created by andylym on 2025/3/7.
//

#import <UIKit/UIKit.h>

@interface UIView (ACExtension)

@property (nonatomic, assign) CGFloat AC_x;
@property (nonatomic, assign) CGFloat AC_y;
@property (nonatomic, assign) CGFloat AC_width;
@property (nonatomic, assign) CGFloat AC_height;
@property (nonatomic, assign) CGFloat AC_centerX;
@property (nonatomic, assign) CGFloat AC_centerY;
@property (nonatomic, assign) CGSize  AC_size;
@property (nonatomic, assign) CGPoint AC_origin;
@property (nonatomic, assign, readonly) CGFloat AC_maxX;
@property (nonatomic, assign, readonly) CGFloat AC_maxY;


@end

