//
//  ViewController.m
//  demoForToast
//
//  Created by andylym on 2025/3/5.
//

#import "ViewController.h"
#import <Toast/UIView+Toast.h>
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}





- (IBAction)makeAToastBtnAction:(UIButton *)sender {
//    [self.view makeToast:@"test message"];
//    [self.view makeToast:@"test message" duration:1.5 position:CSToastPositionCenter];
    
    [self.view makeToast:@"test message" duration:1.5 position:CSToastPositionCenter title:@"test title" image:[UIImage imageNamed:@"icon"] style:[CSToastManager sharedStyle] completion:^(BOOL didTap) {
        NSLog(@"didTap : %d", didTap);
    }];
}

@end
