//
//  SceneDelegate.h
//  demoForToast
//
//  Created by andylym on 2025/3/5.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

