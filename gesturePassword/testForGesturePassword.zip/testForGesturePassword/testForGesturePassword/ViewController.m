//
//  ViewController.m
//  testForGesturePassword
//
//  Created by andylym on 2025/3/6.
//

#import "ViewController.h"
#import "ACGestureLockViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
- (IBAction)acGesturePasswordBtnAction:(UIButton *)sender {
    
//    ACGestureLockViewController *next = [[ACGestureLockViewController alloc] initWithUnlockType:ACUnlockTypeCreatePsw];
    ACGestureLockViewController *next = [[ACGestureLockViewController alloc] initWithUnlockType:ACUnlockTypeValidatePsw];
    [next setModalPresentationStyle:UIModalPresentationOverFullScreen];
    [self presentViewController:next animated:YES completion:^{
        NSLog(@"---present success-------");
    }];
    
}


@end
