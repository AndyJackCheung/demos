//
//  ACGestureLockViewController.m
//
//  Created by andylym on 2025/3/6.

#import "ACGestureLockViewController.h"
#import "ACGestureLockView.h"
#import "ACGestureLockIndicator.h"
#import "EasyShowView.h"
#import "EasyShowOptions.h"
#import "SDAutoLayout.h"
#import <Toast/UIView+Toast.h>

#define GesturesPassword @"gesturespassword"

@interface ACGestureLockViewController () <ACGestureLockDelegate, UIAlertViewDelegate>

@property (strong, nonatomic) ACGestureLockView *gestureLockView;
@property (strong, nonatomic) ACGestureLockIndicator *gestureLockIndicator;

// 手势状态栏提示label
@property (weak, nonatomic) UILabel *statusLabel;

// 账户名
@property (weak, nonatomic) UILabel *nameLabel;
// 账户头像
@property (weak, nonatomic) UIImageView *headIcon;

// 其他账户登录按钮
@property (weak, nonatomic) UIButton *otherAcountBtn;
// 重新绘制按钮
@property (weak, nonatomic) UIButton *resetPswBtn;
// 忘记手势密码按钮
@property (weak, nonatomic) UIButton *forgetPswBtn;

// 创建的手势密码
@property (nonatomic, copy) NSString *lastGesturePsw;

@property (nonatomic) ACUnlockType unlockType;

@end

@implementation ACGestureLockViewController

#pragma mark - 类方法

+ (void)deleteGesturesPassword {
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:GesturesPassword];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+ (void)addGesturesPassword:(NSString *)gesturesPassword {
    [[NSUserDefaults standardUserDefaults] setObject:gesturesPassword forKey:GesturesPassword];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+ (NSString *)gesturesPassword {
    return [[NSUserDefaults standardUserDefaults] objectForKey:GesturesPassword];
}

#pragma mark - inint

- (instancetype)initWithUnlockType:(ACUnlockType)unlockType {
    if (self = [super init]) {
        _unlockType = unlockType;
    }
    return self;
}

#pragma mark - viewDidLoad
- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor = [UIColor lightGrayColor];

    [self setupMainUI];

    self.gestureLockView.delegate = self;

    self.resetPswBtn.hidden = YES;
    UIButton*button=[[UIButton alloc]initWithFrame:CGRectMake(10, SafeIS_IPHONE_X, 50, 50)];
    [button setBackgroundImage:UIIMAGE(@"loginClose") forState:UIControlStateNormal];
    [button addTarget:self action:@selector(onclick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    switch (_unlockType) {
        case ACUnlockTypeCreatePsw:
        {
            self.gestureLockIndicator.hidden = NO;
            self.otherAcountBtn.hidden = self.forgetPswBtn.hidden = self.nameLabel.hidden = self.headIcon.hidden = YES;
        }
            break;
        case ACUnlockTypeValidatePsw:
        {
             button.hidden=YES;
            self.gestureLockIndicator.hidden = YES;
            self.otherAcountBtn.hidden = self.forgetPswBtn.hidden = self.nameLabel.hidden = self.headIcon.hidden = NO;
            self.forgetPswBtn.hidden =  YES;
        }
            break;
        case ACUnlockTypeDeletePsw:
        {
            self.gestureLockIndicator.hidden = YES;
            self.otherAcountBtn.hidden = self.forgetPswBtn.hidden = self.nameLabel.hidden = self.headIcon.hidden = YES;

        }
            break;
        default:
            break;
    }

}
-(void)onclick{
    [self dismissViewControllerAnimated:YES completion:^{
        NSLog(@"-------dismiss success-----");
    }];
}
// 创建界面
- (void)setupMainUI {

    CGFloat maginX = 15;
    CGFloat magin = 5;
    CGFloat btnW = ([UIScreen mainScreen].bounds.size.width - maginX * 2 - magin * 2) / 3;
    CGFloat btnH = 50;

//    // 手势密码 titile
    UILabel *nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 100 * kWindowWHOne, kWindowW, 40)];
    nameLabel.textAlignment = NSTextAlignmentCenter;
    nameLabel.text = @"手势密码";
    nameLabel.font = [UIFont systemFontOfSize:26 * kWindowWHOne];
    nameLabel.textColor = [UIColor blackColor];
    [self.view addSubview:nameLabel];

    // 手势状态栏提示label
    UILabel *statusLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(nameLabel.frame) + 10, self.view.frame.size.width, 30)];
    statusLabel.textAlignment = NSTextAlignmentCenter;
    if (self.unlockType==ACUnlockTypeCreatePsw) {
        statusLabel.text =@"请绘制手势密码";

    }else{
        statusLabel.text = @"请输入手势密码";
    }
    statusLabel.font = [UIFont systemFontOfSize:15];
    statusLabel.textColor = [UIColor redColor];
    [self.view addSubview:statusLabel];
    self.statusLabel = statusLabel;
    // 九宫格 手势密码页面
    ACGestureLockView *gestureLockView = [[ACGestureLockView alloc]initWithFrame:CGRectMake(0, statusLabel.bottom + 20 * kWindowWHOne, self.view.frame.size.width, self.view.frame.size.width)];
    gestureLockView.delegate = self;
    [self.view addSubview:gestureLockView];
    self.gestureLockView = gestureLockView;

    // 底部三个按钮
    // 其他账户登录按钮
    UIButton *otherAcountBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    otherAcountBtn.frame = CGRectMake(maginX, self.view.frame.size.height - 50 - btnH, btnW, btnH);// 30
    otherAcountBtn.backgroundColor = [UIColor clearColor];
    [otherAcountBtn setTitle:@"忘记手势密码" forState:UIControlStateNormal];
    otherAcountBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    [otherAcountBtn setTitleColor:[UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:1] forState:UIControlStateNormal];
    [otherAcountBtn addTarget:self action:@selector(otherAccountLogin:) forControlEvents:UIControlEventTouchUpInside];
    //[self.view addSubview:otherAcountBtn];
    self.otherAcountBtn = otherAcountBtn;

    // 重新绘制按钮
    UIButton *resetPswBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    resetPswBtn.frame = CGRectMake(CGRectGetMaxX(otherAcountBtn.frame) + magin, otherAcountBtn.frame.origin.y, btnW, btnH);
    resetPswBtn.backgroundColor = otherAcountBtn.backgroundColor;
    [resetPswBtn setTitle:@"重新绘制" forState:UIControlStateNormal];
    resetPswBtn.titleLabel.font = [UIFont systemFontOfSize:12];
    [resetPswBtn setTitleColor:[UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:1] forState:UIControlStateNormal];
    [resetPswBtn addTarget:self action:@selector(resetGesturePassword:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:resetPswBtn];
    self.resetPswBtn = resetPswBtn;

    // 忘记手势密码按钮
    UIButton *forgetPswBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    forgetPswBtn.frame = CGRectMake(CGRectGetMaxX(resetPswBtn.frame) + magin, otherAcountBtn.frame.origin.y, btnW, btnH);
    forgetPswBtn.backgroundColor = otherAcountBtn.backgroundColor;
    [forgetPswBtn setTitle:@"忘记手势密码" forState:UIControlStateNormal];
    forgetPswBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    [forgetPswBtn setTitleColor:[UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:1] forState:UIControlStateNormal];
    [forgetPswBtn addTarget:self action:@selector(forgetGesturesPassword:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:forgetPswBtn];
    self.forgetPswBtn = forgetPswBtn;
}

#pragma mark - private

//  创建手势密码
- (void)createGesturesPassword:(NSMutableString *)gesturesPassword {

    if (self.lastGesturePsw.length == 0) {

        if (gesturesPassword.length < 4) {
            self.statusLabel.text = @"至少连接四个点，请重新输入";
            [self shakeAnimationForView:self.statusLabel];
            return;
        }

        if (self.resetPswBtn.hidden == YES) {
            self.resetPswBtn.hidden = NO;
        }

        self.lastGesturePsw = gesturesPassword;
        [self.gestureLockIndicator setGesturePassword:gesturesPassword];
        self.statusLabel.text = @"请再次绘制手势密码";
        return;
    }

    if ([self.lastGesturePsw isEqualToString:gesturesPassword]) { // 绘制成功
        // 保存手势密码
        [ACGestureLockViewController addGesturesPassword:gesturesPassword];
        [self dismissViewControllerAnimated:YES completion:^{

        }];

    }else {
        self.statusLabel.text = @"与上一次绘制不一致，请重新绘制";
        [self shakeAnimationForView:self.statusLabel];
    }


}

// 验证手势密码
- (void)validateGesturesPassword:(NSMutableString *)gesturesPassword {

    static NSInteger errorCount = 5;

    if ([gesturesPassword isEqualToString:[ACGestureLockViewController gesturesPassword]]) {
        if (self.unlockType==ACUnlockTypeValidatePsw) {
            [self dismissViewControllerAnimated:YES completion:^{
                errorCount = 5;
            }];

        }else{
            //验证之后删除密码
//            [ACGestureLockViewController deleteGesturesPassword];
            [self dismissViewControllerAnimated:YES completion:nil];
        }

    } else {

        if (errorCount - 1 == 0) { // 你已经输错五次了！ 退出重新登陆！
            if (self.unlockType==ACUnlockTypeDeletePsw) {
                errorCount = 5;
                 [self.view makeToast:@"输入错误次数已超出限制，请稍后再试！" duration:1.5 position:CSToastPositionCenter];
                dispatch_time_t delayTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0/*延迟执行时间*/ * NSEC_PER_SEC));
                dispatch_after(delayTime, dispatch_get_main_queue(), ^{
                   [self dismissViewControllerAnimated:YES completion:nil];
                });
                return;
            }else{
                errorCount = 5;
                EasyShowAlertView *showView = [EasyShowAlertView showAlertWithTitle:@"提示" message:@"手势密码已失效，请重新登录"];

                [showView addItemWithTitle:@"确定" itemType:ShowAlertItemTypeBlodBlack callback:^(EasyShowAlertView *showview) {
                    NSLog(@"--------退出登录--------");
                }];
                [EasyShowOptions sharedEasyShowOptions].alertTintColor = [UIColor clearColor];
                [showView show];
                return;
            }
        }
        self.statusLabel.text = [NSString stringWithFormat:@"密码错误，还可以再输入%ld次",--errorCount];
        [self shakeAnimationForView:self.statusLabel];
    }
}

// 抖动动画
- (void)shakeAnimationForView:(UIView *)view {

    CALayer *viewLayer = view.layer;
    CGPoint position = viewLayer.position;
    CGPoint left = CGPointMake(position.x - 10, position.y);
    CGPoint right = CGPointMake(position.x + 10, position.y);

    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"position"];
    [animation setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut]];
    [animation setFromValue:[NSValue valueWithCGPoint:left]];
    [animation setToValue:[NSValue valueWithCGPoint:right]];
    [animation setAutoreverses:YES]; // 平滑结束
    [animation setDuration:0.08];
    [animation setRepeatCount:3];

    [viewLayer addAnimation:animation forKey:nil];
}

#pragma mark - 按钮点击事件 Anction

// 点击其他账号登陆按钮
- (void)otherAccountLogin:(id)sender {
//    NSLog(@"%s",__FUNCTION__);
}

// 点击重新绘制按钮
- (void)resetGesturePassword:(id)sender {
//    NSLog(@"%s",__FUNCTION__);

    self.lastGesturePsw = nil;
    self.statusLabel.text = @"请绘制手势密码";
    self.resetPswBtn.hidden = YES;
    [self.gestureLockIndicator setGesturePassword:@""];
}

// 点击忘记手势密码按钮
- (void)forgetGesturesPassword:(id)sender {
    NSLog(@"----forgetGesturesPassword------");
    [EasyShowOptions sharedEasyShowOptions].alertAnimationType = alertAnimationTypePush ;// alertAnimationTypePush
    //设置主题颜色
    [EasyShowOptions sharedEasyShowOptions].alertTintColor = [UIColor redColor];
    EasyShowAlertView *showView = [EasyShowAlertView showAlertWithTitle:@"提示" message:@"忘记手势,可以使用账号密码登录，登录后需重新绘制手势图案"];
    [showView addItemWithTitle:@"取消" itemType:ShowAlertItemTypeBlodBlack callback:^(EasyShowAlertView *showview) {
            NSLog(@"--------取消--------");
        }];
    [showView addItemWithTitle:@"确定" itemType:ShowAlertItemTypeBlodBlack callback:^(EasyShowAlertView *showview) {
            NSLog(@"--------退出登录--------");
        }];
    [EasyShowOptions sharedEasyShowOptions].alertTintColor = [UIColor blueColor];

    [showView show];
}

#pragma mark - ACgestureLockViewDelegate

- (void)gestureLockView:(ACGestureLockView *)lockView drawRectFinished:(NSMutableString *)gesturePassword {

    switch (_unlockType) {
        case ACUnlockTypeCreatePsw: // 创建手势密码
        {
            [self createGesturesPassword:gesturePassword];
        }
            break;
        case ACUnlockTypeValidatePsw: // 校验手势密码
        {
            [self validateGesturesPassword:gesturePassword];
        }
            break;
        case ACUnlockTypeDeletePsw: // 校验手势密码并删除
        {
            [self validateGesturesPassword:gesturePassword];
        }
            break;
        default:
            break;
    }
}

#pragma mark - UIAlertViewDelegate

-(void)dealloc{


}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
