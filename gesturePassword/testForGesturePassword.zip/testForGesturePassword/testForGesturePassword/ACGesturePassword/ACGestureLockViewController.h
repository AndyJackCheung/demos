//
//  ACGestureLockViewController.h
//
//  Created by andylym on 2025/3/6.

#import <UIKit/UIKit.h>



#define kWindowH   [UIScreen mainScreen].bounds.size.height //应用程序的屏幕高度
#define kWindowW    [UIScreen mainScreen].bounds.size.width  //应用程序的屏幕宽度
#define kWindowHOne    [UIScreen mainScreen].bounds.size.height / 667 //应用程序的屏幕单位高度
#define kWindowWHOne    [UIScreen mainScreen].bounds.size.width / 375 //应用程序的屏幕单位宽度
#define SafeIS_IPHONE_X (kWindowH == 812.0 ? 50 : 30)
//图片
#define UIIMAGE(name) [UIImage imageNamed:name]


typedef NS_ENUM(NSInteger,ACUnlockType) {
    ACUnlockTypeCreatePsw, // 创建手势密码
    ACUnlockTypeValidatePsw,// 登录校验手势密码
    ACUnlockTypeDeletePsw // 校验手势密码并关闭手势解锁
};

@interface ACGestureLockViewController : UIViewController

+ (void)deleteGesturesPassword;//删除手势密码
+ (NSString *)gesturesPassword;//获取手势密码

- (instancetype)initWithUnlockType:(ACUnlockType)unlockType;

@end
