//
//  ACGestureLockView.h
//
//  Created by andylym on 2025/3/6.

#import <UIKit/UIKit.h>
@class ACGestureLockView;

#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

#define Screen_Width [UIScreen mainScreen].bounds.size.width
#define Screen_Height [UIScreen mainScreen].bounds.size.height

@protocol ACGestureLockDelegate <NSObject>

- (void)gestureLockView:(ACGestureLockView *)lockView drawRectFinished:(NSMutableString *)gesturePassword;

@end

@interface ACGestureLockView : UIView

@property (assign, nonatomic) id<ACGestureLockDelegate> delegate;

@end
