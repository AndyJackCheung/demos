//
//  EasyShowLabel.h
//  EasyShowViewDemo
//
//  Created by nf on 2019/12/20.
//  Copyright © 2019年 chenliangloveyou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EasyShowLabel : UILabel

- (instancetype)initWithContentInset:(UIEdgeInsets)contentInset ;

@end
