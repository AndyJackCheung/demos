//
//  ACGestureLockIndicator.h
//
//  Created by andylym on 2025/3/6.

#import <UIKit/UIKit.h>

@interface ACGestureLockIndicator : UIView

- (void)setGesturePassword:(NSString *)gesturePassword;

@end
