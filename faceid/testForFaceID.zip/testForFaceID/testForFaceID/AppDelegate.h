//
//  AppDelegate.h
//  testForFaceID
//
//  Created by andylym on 2025/3/5.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

