//
//  ACBannerCollectionViewCell.m
//
//
//  Created by andylym on 2025/3/7.
//

#import "ACBannerCollectionViewCell.h"



@implementation ACBannerCollectionViewCell

-(instancetype)initWithFrame:(CGRect)frame{

    self = [super initWithFrame:frame];

    if (self) {


         [self layout];
    }

    return self;

}

-(void)layout{
    self.backgroundColor = [UIColor lightGrayColor];
    /*
     *  图片的添加
     */
    _imageView = [[UIImageView alloc]initWithFrame:CGRectMake(16, 0, self.frame.size.width - 32, self.frame.size.height)];
    _imageView.layer.cornerRadius = 5;

    _imageView.layer.masksToBounds = YES;
    
//    _imageView.contentMode = UIViewContentModeScaleAspectFill;
//    _imageView.layer.cornerRadius = 4;
//    _imageView.clipsToBounds = YES;

    [self.contentView addSubview:_imageView];
}

@end
