//
//  ACBannarView.h
//
//
//  Created by andylym on 2025/3/7.
//

#import <UIKit/UIKit.h>
#import "Masonry/Masonry.h"
/** SDWebImage里面的类*/
#import "UIImageView+WebCache.h"
#import "SDImageCache.h"
#import "UIButton+WebCache.h"

#import "BannerModel.h"


#import "ACBannerCollectionViewCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface ACBannarView : UIView

- (id)initWithFrame:(CGRect)frame viewSize:(CGSize)viewSize;

@property (strong, nonatomic) NSArray *items;


@property (copy, nonatomic) void(^imageViewClick)(ACBannarView *barnerview,NSInteger index);
//点击图片
- (void)imageViewClick:(void(^)(ACBannarView *barnerview,NSInteger index))block;


NS_ASSUME_NONNULL_END

@end
