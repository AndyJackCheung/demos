//
//  ACBannerCollectionViewCell.h
//
//
//  Created by andylym on 2025/3/7.
//

#import <UIKit/UIKit.h>
//屏幕尺寸
#define CIO_SCREEN_WIDTH  [UIScreen mainScreen].bounds.size.width
#define CIO_SCREEN_HEIGHT  [UIScreen mainScreen].bounds.size.height



@interface ACBannerCollectionViewCell : UICollectionViewCell

@property (nonatomic,strong) UIImageView *imageView;

@end
