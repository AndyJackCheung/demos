//
//  BannerModel.m
//
//  Created by andylym on 2025/3/7.
//

#import "BannerModel.h"

@implementation BannerModel

@end
