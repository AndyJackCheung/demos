//
//  ViewController.m
//  testForBanner
//
//  Created by andylym on 2025/3/7.
//

#import "ViewController.h"
#import "ACBannarView.h"
#import <MJExtension/MJExtension.h>

@interface ViewController ()
@property(nonatomic,strong) ACBannarView *bannerView;

@property (nonatomic,strong) NSMutableArray *bannerArr;

@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self setBannerAction];
    
}


- (void)setBannerAction {
    CGRect bannerViewFrame = CGRectMake(0, 10 * CIO_SCREEN_WIDTH, CIO_SCREEN_WIDTH, 150 * CIO_SCREEN_WIDTH);
    bannerViewFrame = CGRectMake(0, 100, CIO_SCREEN_WIDTH, CIO_SCREEN_WIDTH);
    
    self.bannerView = [[ACBannarView alloc]initWithFrame:bannerViewFrame viewSize:CGSizeMake(CIO_SCREEN_WIDTH, CIO_SCREEN_WIDTH)];
    [self getBannerDataAction];

    if (self.bannerArr.count > 0) {
        NSMutableArray *muArr = [NSMutableArray arrayWithCapacity:0];
        for (BannerModel *model in self.bannerArr) {
            [muArr addObject:model.url];
        }
        self.bannerView.items = muArr;
    }
    
    self.bannerView.backgroundColor = [UIColor redColor];
    
    [self.view addSubview:self.bannerView];
    
    //轮播图的图片点击方法
    [self bannerImageClickAction];
    
}
- (void)bannerImageClickAction {
    __weak typeof(self)weakself = self;
    [self.bannerView  imageViewClick:^(ACBannarView * _Nonnull barnerview, NSInteger index) {
        BannerModel *banner = weakself.bannerArr[index];
        if (banner.linkUrl) {
            NSURL *url = [NSURL URLWithString:banner.linkUrl];
            if([[UIDevice currentDevice].systemVersion floatValue] >= 10.0){
                if ([[UIApplication sharedApplication] respondsToSelector:@selector(openURL:options:completionHandler:)]) {
                    if (@available(iOS 10.0, *)) {
                        [[UIApplication sharedApplication] openURL:url options:@{}
                                                 completionHandler:^(BOOL success) {

                                                 }];
                    } else {

                    }
                } else {
                     [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:^(BOOL success) {
                        
                    }];
                   
                }

            } else {
                bool can = [[UIApplication sharedApplication] canOpenURL:url];
                if(can){
                    [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:^(BOOL success) {
                        
                    }];
                }
            }
        }

    }];
    
    
    
}

- (void)getBannerDataAction {
    // 此处resPonseObj为示例，本来应该是从服务器请求到的数据
    NSMutableDictionary *resPonseObj = [NSMutableDictionary dictionary];
    NSMutableArray *dataMArr = [NSMutableArray array];
    NSMutableDictionary *dictFirst = [NSMutableDictionary dictionary];
    NSString *firsUrlStr = @"https://i.hd-r.icu/92adeb9c22203d565ebc10e267bb2248.png";
    [dictFirst setValue:firsUrlStr forKey:@"url"];
    [dictFirst setValue:firsUrlStr forKey:@"linkUrl"];

    [dataMArr addObject:dictFirst];
    NSMutableDictionary *dictSecond = [NSMutableDictionary dictionary];
    NSString *secondUrlStr = @"https://i.hd-r.icu/a0b84df182b1c90501ea060bd813ed0a.png";
    [dictSecond setValue:secondUrlStr forKey:@"url"];
    [dictSecond setValue:secondUrlStr forKey:@"linkUrl"];
    [dataMArr addObject:dictSecond];
    NSMutableDictionary *dictThird = [NSMutableDictionary dictionary];
    NSString *thirdUrlStr = @"https://i.hd-r.icu/357b558e4f6d22c261427b2972e735da.png";
    [dictThird setValue:thirdUrlStr forKey:@"url"];
    [dictThird setValue:thirdUrlStr forKey:@"linkUrl"];

    [dataMArr addObject:dictThird];
    
    [resPonseObj setValue:dataMArr forKey:@"data"];
    
    [self.bannerArr removeAllObjects];
    // 数组转模型使用mj的方法
    [self.bannerArr addObjectsFromArray:[BannerModel mj_objectArrayWithKeyValuesArray:resPonseObj[@"data"]]];
    if (self.bannerArr.count>0) {
        [self configUrlArrayWithModelArray:self.bannerArr];
    }
    
}
-(void)configUrlArrayWithModelArray:(NSMutableArray*)array{
    NSMutableArray*urlArray=[NSMutableArray arrayWithCapacity:0];
    for (int i=0; i<array.count; i++) {
        BannerModel*model=array[i];
        [urlArray addObject:model.url];
    }
    self.bannerView.items=urlArray;
}


- (NSMutableArray *)bannerArr{
    if (!_bannerArr) {
        _bannerArr = [NSMutableArray arrayWithCapacity:0];
    }
    return _bannerArr;
}
@end
