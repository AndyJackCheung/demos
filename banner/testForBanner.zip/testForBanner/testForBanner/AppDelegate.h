//
//  AppDelegate.h
//  testForBanner
//
//  Created by andylym on 2025/3/7.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

